<?php get_header(); ?>

<!-- Content Starts -->
<div id="single" class="content wrap">
        
    <?php if (have_posts()) : $count = 0; ?>
    <?php while (have_posts()) : the_post(); $count++; ?>
                                                                
        <div id="single-post" class="fl">
        
            <!-- Post Starts -->
            <div class="box-bg">
            <div class="single-post post box">

                <h2><?php the_title(); ?></h2>
                <?php the_content(); ?>

            </div>
            </div>
            <!-- Post Ends -->

			<?php if ('open' == $post->comment_status) : ?>
            <div class="box-bg">
            <div id="comments" class="box">
                <?php comments_template(); ?>
            </div>
            </div>
            <?php endif; ?>
        
        </div>
        
        <?php get_sidebar(); ?>            
                                            
    <?php endwhile; else: ?>
        <p><?php _e('Sorry, no posts matched your criteria.',woothemes) ?></p>
    <?php endif; ?>  
    
</div><!-- Content Ends -->
    
<?php get_footer(); ?>