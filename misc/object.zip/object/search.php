<?php get_header(); ?>
       
    <!-- Content Starts -->
    <div class="content archive">
    
        <div id="single-post" class="fl">
            
            <?php if (have_posts()) : $count = 0; ?>
                <h2 class="arh"><?php _e('Search results',woothemes) ?></h2>
            <?php while (have_posts()) : the_post(); $count++; ?>
                                                                        
                <!-- Post Starts -->
                <div class="box-bg">
                <div class="single-post post box">
        
                    <h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                    <p class="post-details"><?php _e('Posted on',woothemes); ?> <?php the_time('d. M, Y'); ?> <?php _e('by',woothemes); ?> <?php the_author_posts_link(); ?> <?php _e('in',woothemes); ?> <?php the_category(', ') ?></p>
                    
                    <?php the_excerpt(); ?>
                    <?php the_tags('<p class="tags">Tags: ', ', ', '</p>'); ?>
        
                </div>
                </div>
                <!-- Post Ends -->
                                                    
                <?php endwhile; else: ?>
                    <p><?php _e('Sorry, no posts matched your criteria.',woothemes) ?></p>
                <?php endif; ?>  
        
                <div class="more_entries">
                    <?php if (function_exists('wp_pagenavi')) wp_pagenavi(); else { ?>
                    <div class="alignleft bg"><?php previous_posts_link(__('&laquo; Newer Entries ',woothemes)) ?></div>
                    <div class="alignright bg"><?php next_posts_link(__(' Older Entries &raquo;',woothemes)) ?></div>
                    <br class="fix" />
                    <?php } ?> 
                </div>		
                <div class="fix"></div>
                
        </div><!-- .col-left ends -->

        <?php get_sidebar(); ?>
         <div class="fix"></div>
    </div><!-- Content Ends -->
		
<?php get_footer(); ?>


