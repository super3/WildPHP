<!-- Content Starts -->
<div id="single" class="content wrap">
        
    <?php if (have_posts()) : $count = 0; ?>
    <?php while (have_posts()) : the_post(); $count++; ?>
                                                                
        <div id="single-post" class="fl">
        
            <!-- Post Starts -->
            <div class="box-bg">
            <div class="single-post post box">

                <h2><?php the_title(); ?></h2>
                <p class="post-details"><?php _e('Posted on',woothemes); ?> <?php the_time('d. M, Y'); ?> <?php _e('by',woothemes); ?> <?php the_author_posts_link(); ?> <?php _e('in',woothemes); ?> <?php the_category(', ') ?></p>
                
                <?php the_content(); ?>
                <?php the_tags('<p class="tags">Tags: ', ', ', '</p>'); ?>

            </div>
            </div>
            <!-- Post Ends -->

            <div class="box-bg">
            <div id="comments" class="box">
                <?php comments_template(); ?>
            </div>
            </div>
        
        </div>
        
        <?php get_sidebar(); ?>            
                                            
    <?php endwhile; else: ?>
        <p><?php _e('Sorry, no posts matched your criteria.',woothemes) ?></p>
    <?php endif; ?>  
    
</div><!-- Content Ends -->
		
