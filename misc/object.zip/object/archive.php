<?php get_header(); ?>

	<?php 

	// Select which post template to use
	if ( $GLOBALS[blog_id] <> '' && ( in_parent_category($GLOBALS[blog_id]) || is_category($GLOBALS[blog_id]) ) )  
		include (TEMPLATEPATH . "/archive-blog.php"); 
	else
		include (TEMPLATEPATH . "/archive-photo.php"); 	
	
	?>
		
<?php get_footer(); ?>