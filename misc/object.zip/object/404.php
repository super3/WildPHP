<?php get_header(); ?>
          
    <!-- Content Starts -->
    <div id="single" class="content wrap">
                                                                
        <div id="single-post" class="fl">
        
            <!-- Post Starts -->
            <div class="box-bg">
            <div class="single-post post box">

                <h2 class="page"><?php _e('Error 404 - Page not found!',woothemes) ?></h2>
                <p><?php _e('The page you trying to reach does not exist, or has been moved. Please use the menus or the search box to find what you are looking for.',woothemes) ?></p>

            </div>
            </div>
            <!-- Post Ends -->

        </div>
        
        <?php get_sidebar(); ?>            
                                                        
    </div><!-- Content Ends -->

		
<?php get_footer(); ?>