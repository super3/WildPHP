<?php get_header(); ?>
       
	<?php 
	// Select which post template to use
	if ( in_parent_category($GLOBALS[blog_id]) || in_category($GLOBALS[blog_id]) )  
		include (TEMPLATEPATH . "/single-blog.php"); 	
	else
		include (TEMPLATEPATH . "/single-photo.php"); 
	
	?>
		
<?php get_footer(); ?>