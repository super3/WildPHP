<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">

<title>
<?php if ( is_home() ) { ?><?php bloginfo('name'); ?>&nbsp;|&nbsp;<?php bloginfo('description'); ?><?php } ?>
<?php if ( is_search() ) { ?><?php bloginfo('name'); ?>&nbsp;|&nbsp;<?php _e('Search Results',woothemes); ?><?php } ?>
<?php if ( is_author() ) { ?><?php bloginfo('name'); ?>&nbsp;|&nbsp;<?php _e('Author Archives',woothemes); ?><?php } ?>
<?php if ( is_single() ) { ?><?php wp_title(''); ?>&nbsp;|&nbsp;<?php bloginfo('name'); ?><?php } ?>
<?php if ( is_page() ) { ?><?php bloginfo('name'); ?>&nbsp;|&nbsp;<?php wp_title(''); ?><?php } ?>
<?php if ( is_category() ) { ?><?php bloginfo('name'); ?>&nbsp;|&nbsp;<?php _e('Archive',woothemes); ?>&nbsp;|&nbsp;<?php single_cat_title(); ?><?php } ?>
<?php if ( is_month() ) { ?><?php bloginfo('name'); ?>&nbsp;|&nbsp;<?php _e('Archive',woothemes); ?>&nbsp;|&nbsp;<?php the_time('F'); ?><?php } ?>
<?php if (function_exists('is_tag')) { if ( is_tag() ) { ?><?php bloginfo('name'); ?>&nbsp;|&nbsp;<?php _e('Tag Archive',woothemes); ?>&nbsp;|&nbsp;<?php  single_tag_title("", true); } } ?>
</title>
    
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>" media="screen" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php if ( get_option('woo_feedburner_url') <> "" ) { echo get_option('woo_feedburner_url'); } else { echo get_bloginfo_rss('rss2_url'); } ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
   
<!--[if IE 6]>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/includes/js/pngfix.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/includes/js/menu.js"></script>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_directory'); ?>/ie6.css" media="screen" />
<![endif]-->
 
<?php if ( is_single() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head(); ?>

<script type="text/javascript">

	// Cufon font replacement
	Cufon.replace('#single-post h2');
	Cufon.replace('#full-post h2');
	Cufon.replace('.archive h2');	
	Cufon.replace('#photo-meta h2');
	Cufon.replace('#single h3');	
	// Cufon.replace('h3'); 		// Removed because of IE7

	// loopedSlider for image gallery
	jQuery(window).load(function(){
		jQuery("#loopedSlider").loopedSlider({
	<?php
		$autoStart = 0;
		$slidespeed = 600;
		$containerClick = "false";
		
		if ( get_option("woo_slider_auto") == "true" ) 
		   $autoStart = get_option("woo_slider_interval") * 1000;
		else 
		   $autoStart = 0;
		   
		if ( get_option("woo_slider_speed") <> "" ) 
			$slidespeed = get_option("woo_slider_speed") * 1000;

		if ( get_option("woo_slider_click") == "true" )
			$containerClick = "true";
	?>
			autoStart: <?php echo $autoStart; ?>, 
			slidespeed: <?php echo $slidespeed; ?>, 
			containerClick: <?php echo $containerClick; ?>,
			autoHeight: true
		});
	});

</script>

</head>

<body>
<div id="wrap">
<?php 
	// Find the blog category ID from options panel
	$GLOBALS[blog_id] = get_option('woo_blog_id');
?>

<div id="top" class="content">
    
    <div id="header">
        <!-- Logo -->       
        <a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('description'); ?>" class="logo"><img class="title" src="<?php if ( get_option('woo_logo') <> "" ) { echo get_option('woo_logo'); } else { bloginfo('template_directory'); ?>/images/logo.png<?php } ?>" alt="<?php bloginfo('name'); ?>" /></a>
        <h1><a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a></h1>
        
        <!-- Top Ad / Slogan / Search -->
        <?php if (get_option('woo_ad_top') == "true") 
			include (TEMPLATEPATH . "/ads/top_ad.php"); 
		elseif ( get_option('woo_twitter') ) { ?>
        <ul id="twitter_update_list"><li></li></ul>
		<?php } elseif ( get_option('woo_search_top') == "true" ) { ?>
        <div id="search-top"><?php include(TEMPLATEPATH . '/search-form.php'); ?></div>
		<?php } else { ?>
        <p id="tagline"><?php bloginfo('description'); ?></p>
        <?php } ?>
        <div class="fix"></div>
    </div>
    <!-- Menu Starts -->
    <div id="bg-top-nav">
    <div id="top-nav" class="wrap">

        <!-- Category Menu -->       
        <ul class="nav fl">
            <?php if (is_page()) { $highlight = "page_item"; } else {$highlight = "page_item current_page_item"; } ?>
            <li class="<?php echo $highlight; ?>"><a href="<?php bloginfo('url'); ?>"><?php _e('Home',woothemes) ?></a></li>
			<?php if ( get_option('woo_blog_cats') == "true" ) $depth = 3; else $depth = 1; ?>
            <?php wp_list_categories('sort_column=menu_order&depth='.$depth.'&title_li=&exclude='.get_option('woo_nav_exclude')); ?>                
        </ul>

        <!-- RSS -->       
        <ul class="rss fr">
            <li><a href="<?php if ( get_option('woo_feedburner_url') <> "" ) { echo get_option('woo_feedburner_url'); } else { echo get_bloginfo_rss('rss2_url'); } ?>"><img src="<?php bloginfo('template_directory'); ?>/images/ico-rss.png" alt="RSS" /></a></li>
        </ul>

        <!-- Page Menu -->       
        <ul class="nav fr">
            <?php wp_list_pages('sort_column=menu_order&depth=3&title_li=&exclude='.get_option('woo_nav_exclude')); ?>
        </ul>            

    </div>
    </div>
    <!-- Menu Ends -->
    
</div>
