<div id="search_main" class="block">
    <form method="get" id="searchform" action="<?php bloginfo('url'); ?>">
        <div>
        <input type="text" class="field" name="s" id="s"  value="<?php _e('Enter Keywords...',woothemes) ?>" onfocus="if (this.value == '<?php _e('Enter Keywords...',woothemes) ?>') {this.value = '';}" onblur="if (this.value == '') {this.value = '<?php _e('Enter Keywords...',woothemes) ?>';}" />
        <input name="submit" type="submit" class="submit" value="<?php _e('Search',woothemes) ?>" />
        </div>
    </form>
</div>
