<?php



function woo_options(){
// VARIABLES
$themename = "Object";
$manualurl = 'http://www.woothemes.com/support/theme-documentation/object';
$shortname = "woo";



$GLOBALS['template_path'] = get_bloginfo('template_directory');

//Access the WordPress Categories via an Array
$woo_categories = array();  
$woo_categories_obj = get_categories('hide_empty=0');
foreach ($woo_categories_obj as $woo_cat) {
    $woo_categories[$woo_cat->cat_ID] = $woo_cat->cat_name;}
$categories_tmp = array_unshift($woo_categories, "Select a category:");    
       
//Access the WordPress Pages via an Array
$woo_pages = array();
$woo_pages_obj = get_pages('sort_column=post_parent,menu_order');    
foreach ($woo_pages_obj as $woo_page) {
    $woo_pages[$woo_page->ID] = $woo_page->post_name; }
$woo_pages_tmp = array_unshift($woo_pages, "Select a page:");       


//Testing 
$options_select = array("one","two","three","four","five"); 
$options_radio = array("1" => "One","2" => "Two","3" => "Three","4" => "Four","5" => "Five"); 

//Stylesheets Reader
$alt_stylesheet_path = TEMPLATEPATH . '/styles/';
$alt_stylesheets = array();

if ( is_dir($alt_stylesheet_path) ) {
    if ($alt_stylesheet_dir = opendir($alt_stylesheet_path) ) { 
        while ( ($alt_stylesheet_file = readdir($alt_stylesheet_dir)) !== false ) {
            if(stristr($alt_stylesheet_file, ".css") !== false) {
                $alt_stylesheets[] = $alt_stylesheet_file;
            }
        }    
    }
}

//More Options
$all_uploads_path = get_bloginfo('home') . '/wp-content/uploads/';
$all_uploads = get_option('woo_uploads');
$other_entries = array("Select a number:","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19");

// THIS IS THE DIFFERENT FIELDS
$options = array();   

$options[] = array( "name" => "General Settings",
                    "type" => "heading");
                        
$options[] = array( "name" => "Theme Stylesheet",
					"desc" => "Select your themes alternative color scheme.",
					"id" => $shortname."_alt_stylesheet",
					"std" => "default.css",
					"type" => "select",
					"options" => $alt_stylesheets);

$options[] = array( "name" => "Custom Logo",
					"desc" => "Upload a logo for your theme, or specify the image address of your online logo. (http://yoursite.com/logo.png)",
					"id" => $shortname."_logo",
					"std" => "",
					"type" => "upload");    
                                                                                     
$options[] = array( "name" => "Custom Favicon",
					"desc" => "Upload a 16px x 16px Png/Gif image that will represent your website's favicon.",
					"id" => $shortname."_custom_favicon",
					"std" => "",
					"type" => "upload"); 
                                               
$options[] = array( "name" => "Tracking Code",
					"desc" => "Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme.",
					"id" => $shortname."_google_analytics",
					"std" => "",
					"type" => "textarea");        

$options[] = array( "name" => "RSS URL",
					"desc" => "Enter your preferred RSS URL. (Feedburner or other)",
					"id" => $shortname."_feedburner_url",
					"std" => "",
					"type" => "text");
                    
$options[] = array( "name" => "Custom CSS",
                    "desc" => "Quickly add some CSS to your theme by adding it to this block.",
                    "id" => $shortname."_custom_css",
                    "std" => "",
                    "type" => "textarea");
    
$options[] = array( "name" => "Layout Options",
					"type" => "heading");    

$options[] = array( "name" => "Number of Columns",
					"desc" => "Select how many columns you want in your layout. ",
					"id" => $shortname."_cols",
					"std" => "3",
					"type" => "radio",
					"options" => $options_radio); 

$options[] = array( "name" => "Image Ratio",
					"desc" => "Enter the ratio of the images to be displayed on front page and archives e.g. 3 and 2 for 3:2 aspect ratio.",
					"id" => $shortname."_image_ratio",
					"std" => "",
					"type" => array( 
									array(  'id' => $shortname. '_ratio1',
											'type' => 'text',
											'std' => 3,
											'meta' => ':'),
									array(  'id' => $shortname. '_ratio2',
											'type' => 'text',
											'std' => 2,
											'meta' => '')
								  ));

$options[] = array( "name" => "Exclude Navigation",
					"desc" => "Enter a comma-separated list of page/category <a href='http://support.wordpress.com/pages/8/'>ID's</a> that you'd like to exclude from the top navigation. (e.g. 12,23,27,44)",
					"id" => $shortname."_nav_exclude",
					"std" => "",
					"type" => "text"); 

$options[] = array( "name" => "Twitter ID",
					"desc" => "Enter your twitter ID to display your latest tweet in the header. Will replace site description.",
					"id" => $shortname."_twitter",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => "Show Search Top",
					"desc" => "Show Search field in top right header. Replaces description and Twitter.",
					"id" => $shortname."_search_top",
					"std" => "false",
					"type" => "checkbox");

$options[] = array(	"name" => "Photo Post Gallery (Slider)",
					"type" => "heading");					
                   
$options[] = array(    "name" => "Animation Speed",
                    "desc" => "The time in <b>seconds</b> the animation between frames will take e.g. 0.6",
                    "id" => $shortname."_slider_speed",
                    "std" => 0.6,
                    "type" => "text");

$options[] = array(    "name" => "Container Click",
                    "desc" => "Allows you to click the slider to go to next photo",
                    "id" => $shortname."_slider_click",
                    "std" => "false",
                    "type" => "checkbox");   

$options[] = array(    "name" => "Disable Navigation Arrows",
                    "desc" => "Set this to not show the navigation arrows over your photo.",
                    "id" => $shortname."_slider_disable_nav",
                    "std" => "false",
                    "type" => "checkbox");   

$options[] = array(    "name" => "Auto Start",
                    "desc" => "Set the slider to start sliding automatically.",
                    "id" => $shortname."_slider_auto",
                    "std" => "false",
                    "type" => "checkbox");   
                    
$options[] = array(    "name" => "Auto Slide Interval",
                    "desc" => "The time in <b>seconds</b> each slide pauses for, before sliding to the next. Only when using Auto Start option above.",
                    "id" => $shortname."_slider_interval",
                    "std" => 4.0,
                    "type" => "text"); 

$options[] = array(	"name" => "Blog Settings",
					"type" => "heading");		

$options[] = array( "name" => "Blog Category ID",
					"desc" => "Please enter the ID of your main blog category. This category and sub categories will be displayed in a blog style throughout the theme.",
					"id" => $shortname."_blog_id",
					"std" => "",
					"type" => "text");							

$options[] = array(	"name" => "Show Category dropdown",
					"desc" => "Display a category dropdown under the Blog menu item.",
					"id" => $shortname."_blog_cats",
					"std" => "true",
					"type" => "checkbox");	

$options[] = array(	"name" => "Show full post?",
					"desc" => "Check this to display the full post eg. use the_content() instead of the_excerpt().",
					"id" => $shortname."_the_content",
					"std" => "true",
					"type" => "checkbox");	
                   
$options[] = array( "name" => "Dynamic Images",
				    "type" => "heading");    

$options[] = array( "name" => "Automatic Image Thumbs",
					"desc" => "Enable this to pull the images that you have uploaded with the WP image uploader. <strong>Must be enabled for the theme to function properly!</strong>",
					"id" => $shortname."_auto_img",
					"std" => "true",
					"type" => "checkbox");    

$options[] = array( "name" => "Enable Dynamic Image Resizer",
					"desc" => "This will enable the thumb.php script. It dynamicaly resizes images on your site.",
					"id" => $shortname."_resize",
					"std" => "true",
					"type" => "checkbox");    
                                                                                                                    
//Advertising
$options[] = array( "name" => "Ads - Top Ad (468x60px)",
                    "type" => "heading");

$options[] = array( "name" => "Enable Ad",
					"desc" => "Enable the ad space",
					"id" => $shortname."_ad_top",
					"std" => "false",
					"type" => "checkbox");    

$options[] = array( "name" => "Adsense code",
					"desc" => "Enter your adsense code (or other ad network code) here.",
					"id" => $shortname."_ad_top_adsense",
					"std" => "",
					"type" => "textarea");

$options[] = array( "name" => "Image Location",
					"desc" => "Enter the URL to the banner ad image location.",
					"id" => $shortname."_ad_top_image",
					"std" => "http://www.woothemes.com/ads/woothemes-468x60-2.gif",
					"type" => "upload");

$options[] = array( "name" => "Destination URL",
					"desc" => "Enter the URL where this banner ad points to.",
					"id" => $shortname."_ad_top_url",
					"std" => "http://www.woothemes.com",
					"type" => "text");                        



update_option('woo_template',$options);      
update_option('woo_themename',$themename);   
update_option('woo_shortname',$shortname);
update_option('woo_manual',$manualurl);

                                     
// Woo Metabox Options
                    

$woo_metaboxes = array(

        "image" => array (
            "name"  => "image",
            "std"  => "",
            "label" => "Custom Thumbnail Image",
            "type" => "upload",
            "desc" => "Upload a thumbnail image if you don't want to use the first image from your WP gallery."
        ),
        "embed" => array (
            "name"  => "embed",
            "std"  => "",
            "label" => "Embed Code",
            "type" => "textarea",
            "desc" => "Enter the video embed code for your video (YouTube, Vimeo or similar)"
        ),
        "meta" => array (
            "name"  => "meta",
            "std"  => "",
            "label" => "Photo Post Meta",
            "type" => "text",
            "desc" => "Enter some details about your photo(s). This will apear in the photo details box."
        )
    );
    
update_option('woo_custom_template',$woo_metaboxes);      

/*
function woo_update_options(){
        $options = get_option('woo_template',$options);  
        foreach ($options as $option){
            update_option($option['id'],$option['std']);
        }   
}

function woo_add_options(){
        $options = get_option('woo_template',$options);  
        foreach ($options as $option){
            update_option($option['id'],$option['std']);
        }   
}


//add_action('switch_theme', 'woo_update_options'); 
if(get_option('template') == 'wooframework'){       
    woo_add_options();
} // end function 
*/


}

add_action('init','woo_options');  

?>