<?php

$use_timthumb = false; 		// Set to false to disable for this section of theme. Images will be downsized instead of resized to 640px width
$repeat = 50; 				// Number of maximum attachments to get 
$photo_size = 'large';		// The WP "size" to use for the large image
$thumb_size = 'thumbnail';	// The WP "size" to use for the thumbnail
$thumb_dim = 70;			// Size of thumbnails

$id = get_the_id();
$attachments = get_children( array(
'post_parent' => $id,
'numberposts' => $repeat,
'post_type' => 'attachment',
'post_mime_type' => 'image',
'order' => 'DESC', 
'orderby' => 'menu_order date')
);
if ( !empty($attachments) ) :
	$counter = 0;
	$photo_output = '';
	$thumb_output = '';	
	foreach ( $attachments as $att_id => $attachment ) {
		$counter++;
		
		// Caption text
		$caption = "";
		if ($attachment->post_excerpt) 
			$caption = '<span class="photo-caption">'.$attachment->post_excerpt.'</span>';	
			
		// Save large photo
		$src = wp_get_attachment_image_src($att_id, $photo_size, true);
		if ( get_option('woo_resize') == "true" && $use_timthumb == "true" )
			$photo_output .= '<div><a href="'. $src[0] .'" rel="lightbox-group"><img src="'. get_bloginfo(template_url).'/thumb.php?src='. $src[0] .'&h=&w=680&q=90&zc=1" class="single-photo" alt="" /></a>'.$caption.'</div>'; 		
		else
			$photo_output .= '<div><a href="'. $src[0] .'" rel="lightbox-group"><img src="'. $src[0] .'" width="680" class="single-photo" alt="" /></a>'.$caption.'</div>'; 
		
		// Save thumbnail
		$src = wp_get_attachment_image_src($att_id, $thumb_size, true);
		$thumb_output .= '<li><a href="#"><img src="'. $src[0] .'" height="'.$thumb_dim.'" width="'.$thumb_dim.'" class="single-thumb" alt="" />' . "</a></li>\n"; 
	}  
endif; ?>

<!-- Start Photo Slider -->
<div id="loopedSlider">
    <div class="container">
        <div class="slides">
            <?php echo $photo_output; // This will show the large photo in the slider ?>
        </div>
    </div>
    
    <?php if ($counter > 1) : ?>
		<?php if (get_option("woo_slider_disable_nav") == "false") { ?>
    <a href="#" class="previous"><img src="<?php bloginfo('template_directory'); ?>/images/prev-slider.png" alt="" /></a>
    <a href="#" class="next"><img src="<?php bloginfo('template_directory'); ?>/images/next-slider.png" alt="" /></a>                     
		<?php } ?>                                       
    <ul class="pagination">
		<?php echo $thumb_output; // This will show the large photo in the slider ?>
    </ul>                      
    <?php endif; ?>
    
<div class="fix"></div>
</div>
<!-- End Photo Slider -->
