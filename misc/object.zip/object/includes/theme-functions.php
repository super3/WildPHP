<?php 
 
// Compress long post titles
function woo_show_title($cols) {
	global $post;
	$title = get_the_title($post->ID); 
	if ( $cols == 3 ) { if ( strlen($title) > 30 ) $title = substr($title,0,30).'...'; }
	elseif ( $cols == 4 ) { if ( strlen($title) > 20 ) $title = substr($title,0,20).'...'; }
	elseif ( $cols == 5 ) { if ( strlen($title) > 12 ) $title = substr($title,0,12).'...'; }
	echo $title; 
}

// Test if the current category is a child of the input category
function in_parent_category($cats, $_post = null)
{
	foreach ((array) $cats as $cat)
	{
		$descendants = get_term_children((int) $cat, "category");
		if ($descendants && in_category($descendants, $_post))
			return true;
	}
	return false;
}
    
?>