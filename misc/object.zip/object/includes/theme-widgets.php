<?php

// =============================== Recent widget ======================================
function recentWidget()
{
	$settings = get_option("widget_recentwidget");
    $title = $settings['title'];
    if ($title == '' or $title == null) $title = 'Recent Posts'; 
    $number = $settings['number'];
    if ($number == '' or $number == null) $number = 3;    

?>
<div id="recent" class="block">
	<h3 class="widget_title"><img src="<?php bloginfo('template_directory'); ?>/images/ico-blog.png" alt="" /><?php echo $title; ?></h3>
    <ul class="news">
         <?php 
         $blog_cat = get_option('woo_blog_cat');
         $posts = get_posts('cat='.$blog_cat.'&showposts='.$number); 
         foreach($posts as $post):
         $id = $post->ID;
         $do_not_duplicate = $id; 
		 $commentcount = $post->comment_count;
         $preview = get_post_meta($post->ID, 'preview', true); ?>
            <li>
                <a href="<?php echo get_permalink($id) ?>"><?php woo_get_image('image','55','55','thumbnail',90,$id,'img'); ?></a>
                <div class="entry fl">
                    <h4><a href="<?php echo get_permalink($id) ?>" rel="bookmark" title="Permanent Link to <?php echo get_the_title($id); ?>"><?php echo get_the_title($id); ?></a></h4>
                    <p class="post_meta"><?php echo get_the_time('F jS, Y',$id) ?><br /><a href="<?php echo get_permalink($id); ?>#comments"><?php echo $commentcount.' '; _e('Comments',woothemes); ?></a></p>
                </div>
                <div class="fix"></div>
            </li>
        <?php endforeach; ?>
    </ul>
</div>
<?php
}

function recentWidgetAdmin() {

	$settings = get_option("widget_recentwidget");

	// check if anything's been sent
	if (isset($_POST['update_recent'])) {
		$settings['title'] = strip_tags(stripslashes($_POST['recent_title']));
		$settings['number'] = strip_tags(stripslashes($_POST['recent_number']));

		update_option("widget_recentwidget",$settings);
	}

	echo '<p>
			<label for="recent_title">Title:<br />
			<input id="recent_title" name="recent_title" type="text" class="widefat" value="'.$settings['title'].'" /></label></p>';
	echo '<p>
			<label for="recent_number">Number of posts:<br />
			<input id="recent_number" name="recent_number" type="text" class="widefat" value="'.$settings['number'].'" /></label></p>';
	echo '<input type="hidden" id="update_recent" name="update_recent" value="1" />';

}

register_sidebar_widget('Woo - Recent (Footer)', 'recentWidget');
register_widget_control('Woo - Recent (Footer)', 'recentWidgetAdmin', 400, 200);

// =============================== Popular widget ======================================
function popularWidget()
{
	$settings = get_option("widget_popularwidget");

    $title = $settings['title'];
    if ($title == '' or $title == null) $title = 'Popular Posts'; 
    $number = $settings['number'];
    if ($number == '' or $number == null) $number = 3;    

?>

<div id="popular" class="block">
	<h3 class="widget_title"><img src="<?php bloginfo('template_directory'); ?>/images/ico-popular.png" alt="" /><?php echo $title; ?></h3>

    <ul class="news">
    <?php
    global $wpdb;
    $result = $wpdb->get_results("SELECT comment_count,ID,post_title FROM $wpdb->posts ORDER BY comment_count DESC LIMIT 0 , $number");
    foreach ($result as $post) {
    setup_postdata($post);
    $postid = $post->ID;
    $commentcount = $post->comment_count;
    if ($commentcount != 0) { 
	?>

    <li>
        <a title="<?php echo get_the_title($postid); ?>" href="<?php echo get_permalink($postid); ?>"><?php woo_get_image('image','55','55','thumbnail',90,$postid,'img'); ?></a>  
        <div class="entry fl">
            <h4><a href="<?php echo get_permalink($postid); ?>"><?php echo get_the_title($postid); ?></a></h4>
            <p class="post_meta"><?php echo get_the_time('F jS, Y',$postid) ?><br /><a href="<?php echo get_permalink($postid); ?>#comments"><?php echo $commentcount.' '; _e('Comments',woothemes); ?></a></p>
        </div>
        <div class="fix"></div>
    </li>
    <?php } } ?>
    </ul>
		
</div>

<?php
}

function popularWidgetAdmin() {

	$settings = get_option("widget_popularwidget");

	// check if anything's been sent
	if (isset($_POST['update_popular'])) {
		$settings['title'] = strip_tags(stripslashes($_POST['popular_title']));
		$settings['number'] = strip_tags(stripslashes($_POST['popular_number']));

		update_option("widget_popularwidget",$settings);
	}

	echo '<p>
			<label for="popular_title">Title:<br />
			<input id="popular_title" name="popular_title" type="text" class="widefat" value="'.$settings['title'].'" /></label></p>';
	echo '<p>
			<label for="popular_number">Number of posts:<br />
			<input id="popular_number" name="popular_number" type="text" class="widefat" value="'.$settings['number'].'" /></label></p>';
	echo '<input type="hidden" id="update_popular" name="update_popular" value="1" />';

}

register_sidebar_widget('Woo - Popular (Footer)', 'popularWidget');
register_widget_control('Woo - Popular (Footer)', 'popularWidgetAdmin', 400, 200);

// =============================== About widget ======================================
function aboutWidget()
{
	$settings = get_option("widget_aboutwidget");

	$title = $settings['title'];
	$text = $settings['text'];
	$btn = $settings['btn'];
	$url = $settings['url'];
	$photo = $settings['photo'];

?>

<div id="about" class="block">
	<h3 class="widget_title"><img src="<?php bloginfo('template_directory'); ?>/images/ico-about.png" alt="" /><?php echo $title; ?></h3>
	<div class="wrap">
    	<?php if ($photo) {  ?><img src="<?php echo htmlentities($photo); ?>" class="gravatar" alt="" /><?php } ?>
		<p><?php echo $text; ?></p>
        <?php if ($url) { ?><a href="<?php echo $url; ?>" class="button"><?php echo $btn; ?></a><?php } ?>
	</div>
</div>

<?php
}

function aboutWidgetAdmin() {

	$settings = get_option("widget_aboutwidget");

	// check if anything's been sent
	if (isset($_POST['update_about'])) {
		$settings['title'] = strip_tags(stripslashes($_POST['about_title']));
		$settings['text'] = strip_tags(stripslashes($_POST['about_text']));
		$settings['btn'] = strip_tags(stripslashes($_POST['about_btn']));
		$settings['url'] = strip_tags(stripslashes($_POST['about_url']));
		$settings['photo'] = strip_tags(stripslashes($_POST['about_photo']));

		update_option("widget_aboutwidget",$settings);
	}

	echo '<p>
			<label for="about_title">Title:<br />
			<input id="about_title" name="about_title" type="text" class="widefat" value="'.$settings['title'].'" /></label></p>';
	echo '<p>
			<label for="about_text">Text:<br />
			<textarea id="about_text" name="about_text" type="textarea" class="widefat">'.$settings['text'].'</textarea></label></p>';
	echo '<p>
			<label for="about_btn">Button text:<br />
			<input id="about_btn" name="about_btn" type="text" class="widefat" value="'.$settings['btn'].'" /></label></p>';
	echo '<p>
			<label for="about_url">Button URL:<br />
			<input id="about_url" name="about_url" type="text" class="widefat" value="'.$settings['url'].'" /></label></p>';
	echo '<p>
			<label for="about_photo">Photo URL:<br />
			<input id="about_photo" name="about_photo" type="text" class="widefat" value="'.$settings['photo'].'" /></label></p>';
	echo '<input type="hidden" id="update_about" name="update_about" value="1" />';

}

register_sidebar_widget('Woo - About (Footer)', 'aboutWidget');
register_widget_control('Woo - About (Footer)', 'aboutWidgetAdmin', 400, 200);

// =============================== Flickr widget ======================================
function flickrWidget()
{
	$settings = get_option("widget_flickrwidget");

	$id = $settings['id'];
	$number = $settings['number'];

?>

<div id="flickr" class="block">
	<h3 class="widget_title"><?php _e('Photos on <span>flick<span>r</span></span>',woothemes); ?></h3>
	<div class="wrap">
		<div class="fix"></div>
		<script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=<?php echo $number; ?>&amp;display=latest&amp;size=s&amp;layout=x&amp;source=user&amp;user=<?php echo $id; ?>"></script>        
		<div class="fix"></div>
	</div>
</div>

<?php
}

function flickrWidgetAdmin() {

	$settings = get_option("widget_flickrwidget");

	// check if anything's been sent
	if (isset($_POST['update_flickr'])) {
		$settings['id'] = strip_tags(stripslashes($_POST['flickr_id']));
		$settings['number'] = strip_tags(stripslashes($_POST['flickr_number']));

		update_option("widget_flickrwidget",$settings);
	}

	echo '<p>
			<label for="flickr_id">Flickr ID (<a href="http://www.idgettr.com">idGettr</a>):
			<input id="flickr_id" name="flickr_id" type="text" class="widefat" value="'.$settings['id'].'" /></label></p>';
	echo '<p>
			<label for="flickr_number">Number of photos:
			<input id="flickr_number" name="flickr_number" type="text" class="widefat" value="'.$settings['number'].'" /></label></p>';
	echo '<input type="hidden" id="update_flickr" name="update_flickr" value="1" />';

}

register_sidebar_widget('Woo - Flickr', 'flickrWidget');
register_widget_control('Woo - Flickr', 'flickrWidgetAdmin', 400, 200);


// =============================== Search widget ======================================
function searchWidget()
{
include(TEMPLATEPATH . '/search-form.php');
}
register_sidebar_widget('Woo - Search', 'SearchWidget');


/* Deregister Default Widgets */
function woo_deregister_widgets(){
    unregister_widget('WP_Widget_Search');         
}
add_action('widgets_init', 'woo_deregister_widgets');  


?>