<?php
	// Determine column/image size front page
	$cols = '3';
	$cols = get_option('woo_cols');
	$r1 = 3; $r2 = 2;
	if (get_option('woo_ratio1')) $r1 = get_option('woo_ratio1');
	if (get_option('woo_ratio2')) $r2 = get_option('woo_ratio2');
	if ( $cols == "1") {
		$class = "one"; $width = 940; $height = $width / $r1 * $r2;
	} elseif ( $cols == 2 ) {
		$class = "two";	$width = 460; 
	} elseif ( $cols == 3 ) {
		$class = "three"; $width = 300;	
	} elseif ( $cols == 4 ) {
		$class = "four"; $width = 220; 
	} elseif ( $cols == 5 ) {
		$class = "five"; $width = 172; 
	}
	$height = $width / $r1 * $r2;	
	$height = round($height);
?>
       
    <!-- Content Starts -->
    <div class="content">
            
    <?php if (have_posts()) : ?>
    <?php while (have_posts()) : the_post(); $count++; ?>
                                                                
        <!-- Post Starts -->
        <div class="bg-photo-thumb <?php echo $class; ?>-col<?php if ($count == $cols) { echo ' last'; $count = 0; } ?>">
        <div class="photo-thumb">
            
            <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" class="thumb">
				<?php woo_get_image('image',$width,$height,null,100,null,'img'); ?> 
            </a>
            <h2>
                <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
                <?php woo_show_title($cols); ?>
                </a>
            </h2>
            <p class="post-details"><?php the_time('d M y'); ?></p>
            <div class="fix"></div>
            
        </div>
        </div>
        <!-- Post Ends -->
                                            
    <?php endwhile; else: ?>
        <p><?php _e('Sorry, no posts matched your criteria.',woothemes) ?></p>
    <?php endif; ?>  

        <div class="fix"></div>
        <div class="more_entries">
            <?php if (function_exists('wp_pagenavi')) wp_pagenavi(); else { ?>
            <div class="alignleft bg"><?php previous_posts_link(__('&laquo; Newer Entries ',woothemes)) ?></div>
            <div class="alignright bg"><?php next_posts_link(__(' Older Entries &raquo;',woothemes)) ?></div>
            <br class="fix" />
            <?php } ?> 
        </div>		
        <div class="fix"></div>
               
    </div><!-- Content Ends -->	