<!-- footer Starts -->
<div id="footer-out">  

    <div id="footer-widgets" class="content">

        <!-- Footer Widget Area Starts -->
        <div class="block">
            <?php dynamic_sidebar('footer-1'); ?>		           
        </div>
        <div class="block">
            <?php dynamic_sidebar('footer-2'); ?>		           
        </div>
        <div class="block last">
            <?php dynamic_sidebar('footer-3'); ?>		           
        </div>
        <!-- Footer Widget Area Ends -->
    </div>
    <div class="fix"></div>       
    
    <div id="footer" class="content wrap">       
        <!-- Bottom Credits -->
        <div class="col-left">
            <p class="credits fl">&copy; <?php echo date('Y'); ?> <?php bloginfo(); ?>. <?php _e('All Rights Reserved.',woothemes) ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|</p>
            <ul class="footer-nav fl">
                <?php wp_list_pages('sort_column=menu_order&depth=1&title_li=&exclude='.get_option('woo_nav_exclude')); ?>
            </ul>                        
        </div>
        <div class="col-right">
            <p class="credits"><?php _e('Designed by',woothemes) ?> <a href="http://www.woothemes.com"><img src="<?php bloginfo('template_directory'); ?>/images/woothemes.png" width="74" height="19" alt="Woo Themes" /></a></p>
        </div>
        <!-- Bottom Credits Ends -->
    </div>
    <div class="fix"></div>

</div>
<!-- footer Ends -->
</div><!-- #wrap ends -->

<?php wp_footer(); ?>

<?php if ( get_option('woo_twitter') ) { ?>
	<script type="text/javascript" src="http://twitter.com/javascripts/blogger.js"></script>
	<script type="text/javascript" src="http://twitter.com/statuses/user_timeline/<?php echo get_option('woo_twitter'); ?>.json?callback=twitterCallback2&amp;count=1"></script>
<?php } ?>

</body>
</html>