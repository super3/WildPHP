     
    <!-- Content Starts -->
    <div id="single" class="content wrap">
            
		<?php if (have_posts()) : the_post();?>
                                                                    
            <div id="sidebar-photo" class="fl">        
                <div class="box-bg">        
                    <div id="photo-meta" class="box">
                        <h2><?php the_title(); ?></h2>
                        <p class="date"><?php the_time('d. M, Y'); ?></p>
                        <p class="author"><?php the_author_posts_link(); ?></p>
                        <p class="category"><?php the_category(', ') ?></p>
                        <p class="comment"><a href="<?php the_permalink(); ?>/#respond">Leave a comment</a></p>
                        <?php the_tags(__('<p class="tags">Tags: ',woothemes), ', ', '</p>'); ?>
						<?php if ( get_post_meta($post->ID, 'meta', true) ) { ?>                        
						<p class="meta"><?php echo get_post_meta($post->ID, 'meta', true); ?></p>
                        <?php } ?>
                    </div>
                </div>
    
                <!-- Widgetized Sidebar -->	
                <?php dynamic_sidebar('sidebar-photo'); ?>	
            </div>
            	                           
			<div id="single-photo" class="fr">

				<?php if ( get_post_meta($post->ID, 'embed', true) ) { ?>
				<div id="loopedSlider">
                	<?php echo woo_get_embed('embed','680','400'); ?>
                </div>		
                <?php } else 				
					include('includes/gallery.php'); // Photo gallery  
				?>
                                            
				<?php if ( get_the_content() ) { ?>
                <!-- Post Starts -->
                <div class="box-bg">
                <div class="single-photo post box">
    
                    <div class="entry">
                        <?php the_content(); ?>
                    </div>
    
                    <div class="fix"></div>
                </div>
                </div>
                <!-- Post Ends -->
				<?php } ?>
    
                <div class="box-bg">
                <div id="comments" class="photo box">
                    <?php comments_template(); ?>
                </div>
                </div>
            
            </div>
                                                
        <?php else: ?>
            <p><?php _e('Sorry, no posts matched your criteria.',woothemes) ?></p>
        <?php endif; ?>  
        
    </div><!-- Content Ends -->
		