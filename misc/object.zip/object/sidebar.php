<div class="box-bg fr">
<div id="sidebar" class="box">        
	<!-- Widgetized Sidebar -->	
	<?php dynamic_sidebar(1); ?>		           
</div>
</div>
<!-- Sidebar Ends -->
